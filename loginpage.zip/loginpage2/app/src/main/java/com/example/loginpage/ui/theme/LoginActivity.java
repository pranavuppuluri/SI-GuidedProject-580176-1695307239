package com.example.loginpage.ui.theme;

import android.app.Activity;

public class LoginActivity extends Activity {
}
